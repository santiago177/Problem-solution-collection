import java.io.*;
import java.util.ArrayList;
     

public class Main {
    
    static ArrayList<String> load_string_blocks(String input) {
        ArrayList<String> blocks = new ArrayList<>();
        char[] s = input.toCharArray();
        for(int i = 0; i < s.length; i += 8) {
            long buffer = 0;
            int iter = 8;
            for(int j = i; j < i+8 && j < s.length; j++) {
                char t = s[j];
                System.out.printf("t = %c\n%s\n", s[j], Integer.toBinaryString(s[j]));                
                buffer = (buffer<<8)|t;
                iter--;
            }
            buffer<<=8*iter;
            System.out.printf("buffer =%s\n", Long.toBinaryString(buffer));
            blocks.add(Long.toBinaryString(buffer));
        }
        return blocks;
    }
    
    public static void main(String[] args) throws IOException {
        File encf = new File("enc.in");
        BufferedReader bf = new BufferedReader(new FileReader(encf));        
        String message = bf.readLine();
        ArrayList<String> blocks = load_string_blocks(message);
        Runtime rt = Runtime.getRuntime();
        String[] commands = new String[blocks.size()+2];
        commands[0] = "des.exe";
        commands[1] = "1";
        for(int i = 0; i < blocks.size(); i++) {
            commands[i+2] = blocks.get(i);
        }
        Process proc = rt.exec(commands);
        BufferedReader stdInput = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        BufferedReader stdError = new BufferedReader(new InputStreamReader(proc.getErrorStream()));
        String s;
        while ((s = stdInput.readLine()) != null) {
            System.out.println(s);
        }
        System.out.println("Errors");
        while ((s = stdError.readLine()) != null) {
            System.out.println(s);
        }
    }

}
